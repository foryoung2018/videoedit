//
//  log.hpp
//  ZPLKantai
//
//  Created by Jack Yang on 8/31/16.
//  Copyright © 2016 Zepp Technology Inc. All rights reserved.
//

#pragma once
#include "zf_log.h"
